import { ComponentCustomProperties } from 'vue'

declare module '@vue/runtime-core' {
  export interface ComponentCustomProperties {
    $http: string
    $validate: (data: object, rule: object) => boolean
  }
}
